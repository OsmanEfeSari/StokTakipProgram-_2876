﻿namespace AMP12A_2876_StokTakipProgram.Pages
{
    partial class frmAnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAnaSayfa));
            this.lblSatış = new System.Windows.Forms.Label();
            this.lblMusterıTelefon = new System.Windows.Forms.Label();
            this.mskTxtMusteriTelefon = new System.Windows.Forms.MaskedTextBox();
            this.btnMusteriSec = new System.Windows.Forms.Button();
            this.İmageAnaSayfa = new System.Windows.Forms.ImageList(this.components);
            this.lblMusteri = new System.Windows.Forms.Label();
            this.txtMusteriAdSoyad = new System.Windows.Forms.TextBox();
            this.SatısYapılıcakUrunler = new System.Windows.Forms.Label();
            this.btnEkle = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.txtNot = new System.Windows.Forms.RichTextBox();
            this.lblnot = new System.Windows.Forms.Label();
            this.btnSatisYap = new System.Windows.Forms.Button();
            this.lblgnltoplam = new System.Windows.Forms.Label();
            this.txtGenelToplam = new System.Windows.Forms.TextBox();
            this.datamenu = new System.Windows.Forms.DataGridView();
            this.Kod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Miktar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ürün_Adı = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BirimFiyat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Toplam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTedarik = new System.Windows.Forms.Label();
            this.lblÜrün = new System.Windows.Forms.Label();
            this.lblSatıs = new System.Windows.Forms.Label();
            this.lblMüsteri = new System.Windows.Forms.Label();
            this.lblPersonel = new System.Windows.Forms.Label();
            this.lblUrun = new System.Windows.Forms.Label();
            this.datagrdurun = new System.Windows.Forms.DataGridView();
            this.lblpersoneladı = new System.Windows.Forms.Label();
            this.lblyetki = new System.Windows.Forms.Label();
            this.lblTl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.datamenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrdurun)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSatış
            // 
            this.lblSatış.AutoSize = true;
            this.lblSatış.Location = new System.Drawing.Point(746, 9);
            this.lblSatış.Name = "lblSatış";
            this.lblSatış.Size = new System.Drawing.Size(76, 13);
            this.lblSatış.TabIndex = 7;
            this.lblSatış.Text = "SATIŞ İŞLEMİ";
            // 
            // lblMusterıTelefon
            // 
            this.lblMusterıTelefon.AutoSize = true;
            this.lblMusterıTelefon.Location = new System.Drawing.Point(746, 62);
            this.lblMusterıTelefon.Name = "lblMusterıTelefon";
            this.lblMusterıTelefon.Size = new System.Drawing.Size(92, 13);
            this.lblMusterıTelefon.TabIndex = 8;
            this.lblMusterıTelefon.Text = "Müşteri Telefonu :";
            // 
            // mskTxtMusteriTelefon
            // 
            this.mskTxtMusteriTelefon.Location = new System.Drawing.Point(844, 59);
            this.mskTxtMusteriTelefon.Mask = "(_____) _____ - _____";
            this.mskTxtMusteriTelefon.Name = "mskTxtMusteriTelefon";
            this.mskTxtMusteriTelefon.Size = new System.Drawing.Size(100, 20);
            this.mskTxtMusteriTelefon.TabIndex = 9;
            // 
            // btnMusteriSec
            // 
            this.btnMusteriSec.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMusteriSec.ImageKey = "people-1085695_1280.png";
            this.btnMusteriSec.ImageList = this.İmageAnaSayfa;
            this.btnMusteriSec.Location = new System.Drawing.Point(949, 59);
            this.btnMusteriSec.Name = "btnMusteriSec";
            this.btnMusteriSec.Size = new System.Drawing.Size(75, 23);
            this.btnMusteriSec.TabIndex = 10;
            this.btnMusteriSec.Text = "Seç";
            this.btnMusteriSec.UseVisualStyleBackColor = true;
            // 
            // İmageAnaSayfa
            // 
            this.İmageAnaSayfa.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("İmageAnaSayfa.ImageStream")));
            this.İmageAnaSayfa.TransparentColor = System.Drawing.Color.Transparent;
            this.İmageAnaSayfa.Images.SetKeyName(0, "png-transparent-profile-icon-computer-icons-business-management-social-media-serv" +
        "ice-people-icon-blue-company-people.png");
            this.İmageAnaSayfa.Images.SetKeyName(1, "people-1085695_1280.png");
            this.İmageAnaSayfa.Images.SetKeyName(2, "arrow-icon-in-flat-style-icon-mui-ten-11553389103lhqxsty2ph.png");
            this.İmageAnaSayfa.Images.SetKeyName(3, "png-transparent-turkey-turkish-lira-sign-currency-symbol-revaluation-of-the-turki" +
        "sh-lira-thumbnail.png");
            this.İmageAnaSayfa.Images.SetKeyName(4, "arrow-icon-in-flat-style-icon-mui-ten-11553389103lhqxsty2ph (1).png");
            this.İmageAnaSayfa.Images.SetKeyName(5, "png-transparent-piggy-bank-money-dollar-saving-logo-bank.png");
            // 
            // lblMusteri
            // 
            this.lblMusteri.AutoSize = true;
            this.lblMusteri.Location = new System.Drawing.Point(759, 100);
            this.lblMusteri.Name = "lblMusteri";
            this.lblMusteri.Size = new System.Drawing.Size(47, 13);
            this.lblMusteri.TabIndex = 11;
            this.lblMusteri.Text = "Müşteri :";
            // 
            // txtMusteriAdSoyad
            // 
            this.txtMusteriAdSoyad.Location = new System.Drawing.Point(832, 97);
            this.txtMusteriAdSoyad.Name = "txtMusteriAdSoyad";
            this.txtMusteriAdSoyad.Size = new System.Drawing.Size(100, 20);
            this.txtMusteriAdSoyad.TabIndex = 12;
            // 
            // SatısYapılıcakUrunler
            // 
            this.SatısYapılıcakUrunler.AutoSize = true;
            this.SatısYapılıcakUrunler.Location = new System.Drawing.Point(853, 140);
            this.SatısYapılıcakUrunler.Name = "SatısYapılıcakUrunler";
            this.SatısYapılıcakUrunler.Size = new System.Drawing.Size(151, 13);
            this.SatısYapılıcakUrunler.TabIndex = 13;
            this.SatısYapılıcakUrunler.Text = "SATIŞ YAPILICAK ÜRÜNLER";
            // 
            // btnEkle
            // 
            this.btnEkle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEkle.ImageKey = "arrow-icon-in-flat-style-icon-mui-ten-11553389103lhqxsty2ph.png";
            this.btnEkle.ImageList = this.İmageAnaSayfa;
            this.btnEkle.Location = new System.Drawing.Point(578, 174);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(75, 23);
            this.btnEkle.TabIndex = 15;
            this.btnEkle.Text = "Ekle";
            this.btnEkle.UseVisualStyleBackColor = true;
            // 
            // btnSil
            // 
            this.btnSil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSil.ImageKey = "arrow-icon-in-flat-style-icon-mui-ten-11553389103lhqxsty2ph (1).png";
            this.btnSil.ImageList = this.İmageAnaSayfa;
            this.btnSil.Location = new System.Drawing.Point(578, 245);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(75, 23);
            this.btnSil.TabIndex = 16;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            // 
            // txtNot
            // 
            this.txtNot.Location = new System.Drawing.Point(776, 420);
            this.txtNot.Name = "txtNot";
            this.txtNot.Size = new System.Drawing.Size(262, 43);
            this.txtNot.TabIndex = 17;
            this.txtNot.Text = "";
            // 
            // lblnot
            // 
            this.lblnot.AutoSize = true;
            this.lblnot.Location = new System.Drawing.Point(666, 423);
            this.lblnot.Name = "lblnot";
            this.lblnot.Size = new System.Drawing.Size(54, 13);
            this.lblnot.TabIndex = 18;
            this.lblnot.Text = "Not Ekle :";
            // 
            // btnSatisYap
            // 
            this.btnSatisYap.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSatisYap.ImageKey = "png-transparent-piggy-bank-money-dollar-saving-logo-bank.png";
            this.btnSatisYap.ImageList = this.İmageAnaSayfa;
            this.btnSatisYap.Location = new System.Drawing.Point(732, 496);
            this.btnSatisYap.Name = "btnSatisYap";
            this.btnSatisYap.Size = new System.Drawing.Size(90, 23);
            this.btnSatisYap.TabIndex = 19;
            this.btnSatisYap.Text = "SATIŞ YAP";
            this.btnSatisYap.UseVisualStyleBackColor = true;
            // 
            // lblgnltoplam
            // 
            this.lblgnltoplam.AutoSize = true;
            this.lblgnltoplam.Location = new System.Drawing.Point(853, 501);
            this.lblgnltoplam.Name = "lblgnltoplam";
            this.lblgnltoplam.Size = new System.Drawing.Size(79, 13);
            this.lblgnltoplam.TabIndex = 20;
            this.lblgnltoplam.Text = "Genel Toplam :";
            // 
            // txtGenelToplam
            // 
            this.txtGenelToplam.Location = new System.Drawing.Point(938, 498);
            this.txtGenelToplam.Name = "txtGenelToplam";
            this.txtGenelToplam.Size = new System.Drawing.Size(100, 20);
            this.txtGenelToplam.TabIndex = 21;
            // 
            // datamenu
            // 
            this.datamenu.AllowUserToAddRows = false;
            this.datamenu.AllowUserToDeleteRows = false;
            this.datamenu.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.datamenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datamenu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Kod,
            this.Miktar,
            this.Ürün_Adı,
            this.BirimFiyat,
            this.Toplam});
            this.datamenu.Location = new System.Drawing.Point(659, 174);
            this.datamenu.Name = "datamenu";
            this.datamenu.Size = new System.Drawing.Size(494, 208);
            this.datamenu.TabIndex = 22;
            this.datamenu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // Kod
            // 
            this.Kod.HeaderText = "Kod";
            this.Kod.Name = "Kod";
            // 
            // Miktar
            // 
            this.Miktar.HeaderText = "Miktar";
            this.Miktar.Name = "Miktar";
            // 
            // Ürün_Adı
            // 
            this.Ürün_Adı.HeaderText = "Ürün Adı";
            this.Ürün_Adı.Name = "Ürün_Adı";
            // 
            // BirimFiyat
            // 
            this.BirimFiyat.HeaderText = "BirimFiyat";
            this.BirimFiyat.Name = "BirimFiyat";
            // 
            // Toplam
            // 
            this.Toplam.HeaderText = "Toplam";
            this.Toplam.Name = "Toplam";
            // 
            // lblTedarik
            // 
            this.lblTedarik.AutoSize = true;
            this.lblTedarik.Location = new System.Drawing.Point(0, 9);
            this.lblTedarik.Name = "lblTedarik";
            this.lblTedarik.Size = new System.Drawing.Size(123, 13);
            this.lblTedarik.TabIndex = 0;
            this.lblTedarik.Text = "TEDARİKÇİ İŞLEMLERİ";
            // 
            // lblÜrün
            // 
            this.lblÜrün.AutoSize = true;
            this.lblÜrün.Location = new System.Drawing.Point(129, 9);
            this.lblÜrün.Name = "lblÜrün";
            this.lblÜrün.Size = new System.Drawing.Size(98, 13);
            this.lblÜrün.TabIndex = 1;
            this.lblÜrün.Text = "ÜRÜN İŞLEMLERİ";
            // 
            // lblSatıs
            // 
            this.lblSatıs.AutoSize = true;
            this.lblSatıs.Location = new System.Drawing.Point(233, 9);
            this.lblSatıs.Name = "lblSatıs";
            this.lblSatıs.Size = new System.Drawing.Size(101, 13);
            this.lblSatıs.TabIndex = 2;
            this.lblSatıs.Text = "SATIŞ DETAYLARI";
            // 
            // lblMüsteri
            // 
            this.lblMüsteri.AutoSize = true;
            this.lblMüsteri.Location = new System.Drawing.Point(340, 9);
            this.lblMüsteri.Name = "lblMüsteri";
            this.lblMüsteri.Size = new System.Drawing.Size(115, 13);
            this.lblMüsteri.TabIndex = 3;
            this.lblMüsteri.Text = "MÜŞTERİ İŞLEMLERİ";
            // 
            // lblPersonel
            // 
            this.lblPersonel.AutoSize = true;
            this.lblPersonel.Location = new System.Drawing.Point(461, 9);
            this.lblPersonel.Name = "lblPersonel";
            this.lblPersonel.Size = new System.Drawing.Size(124, 13);
            this.lblPersonel.TabIndex = 4;
            this.lblPersonel.Text = "PERSONEL İŞLEMLERİ";
            // 
            // lblUrun
            // 
            this.lblUrun.AutoSize = true;
            this.lblUrun.Location = new System.Drawing.Point(0, 27);
            this.lblUrun.Name = "lblUrun";
            this.lblUrun.Size = new System.Drawing.Size(82, 13);
            this.lblUrun.TabIndex = 5;
            this.lblUrun.Text = "ÜRÜN LİSTESİ";
            // 
            // datagrdurun
            // 
            this.datagrdurun.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrdurun.Location = new System.Drawing.Point(3, 43);
            this.datagrdurun.Name = "datagrdurun";
            this.datagrdurun.Size = new System.Drawing.Size(569, 519);
            this.datagrdurun.TabIndex = 6;
            // 
            // lblpersoneladı
            // 
            this.lblpersoneladı.AutoSize = true;
            this.lblpersoneladı.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblpersoneladı.Location = new System.Drawing.Point(975, 9);
            this.lblpersoneladı.Name = "lblpersoneladı";
            this.lblpersoneladı.Size = new System.Drawing.Size(66, 13);
            this.lblpersoneladı.TabIndex = 23;
            this.lblpersoneladı.Text = "Personel Adı";
            // 
            // lblyetki
            // 
            this.lblyetki.AutoSize = true;
            this.lblyetki.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblyetki.Location = new System.Drawing.Point(1112, 9);
            this.lblyetki.Name = "lblyetki";
            this.lblyetki.Size = new System.Drawing.Size(31, 13);
            this.lblyetki.TabIndex = 24;
            this.lblyetki.Text = "Yetki";
            // 
            // lblTl
            // 
            this.lblTl.AutoSize = true;
            this.lblTl.Location = new System.Drawing.Point(1044, 501);
            this.lblTl.Name = "lblTl";
            this.lblTl.Size = new System.Drawing.Size(13, 13);
            this.lblTl.TabIndex = 26;
            this.lblTl.Text = "₺";
            // 
            // frmAnaSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1155, 590);
            this.Controls.Add(this.lblTl);
            this.Controls.Add(this.lblyetki);
            this.Controls.Add(this.lblpersoneladı);
            this.Controls.Add(this.datamenu);
            this.Controls.Add(this.txtGenelToplam);
            this.Controls.Add(this.lblgnltoplam);
            this.Controls.Add(this.btnSatisYap);
            this.Controls.Add(this.lblnot);
            this.Controls.Add(this.txtNot);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.SatısYapılıcakUrunler);
            this.Controls.Add(this.txtMusteriAdSoyad);
            this.Controls.Add(this.lblMusteri);
            this.Controls.Add(this.btnMusteriSec);
            this.Controls.Add(this.mskTxtMusteriTelefon);
            this.Controls.Add(this.lblMusterıTelefon);
            this.Controls.Add(this.lblSatış);
            this.Controls.Add(this.datagrdurun);
            this.Controls.Add(this.lblUrun);
            this.Controls.Add(this.lblPersonel);
            this.Controls.Add(this.lblMüsteri);
            this.Controls.Add(this.lblSatıs);
            this.Controls.Add(this.lblÜrün);
            this.Controls.Add(this.lblTedarik);
            this.Name = "frmAnaSayfa";
            this.Text = "STOK_TAKİP_PROGRAMI";
            ((System.ComponentModel.ISupportInitialize)(this.datamenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrdurun)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblSatış;
        private System.Windows.Forms.Label lblMusterıTelefon;
        private System.Windows.Forms.MaskedTextBox mskTxtMusteriTelefon;
        private System.Windows.Forms.Button btnMusteriSec;
        private System.Windows.Forms.ImageList İmageAnaSayfa;
        private System.Windows.Forms.Label lblMusteri;
        private System.Windows.Forms.TextBox txtMusteriAdSoyad;
        private System.Windows.Forms.Label SatısYapılıcakUrunler;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.RichTextBox txtNot;
        private System.Windows.Forms.Label lblnot;
        private System.Windows.Forms.Button btnSatisYap;
        private System.Windows.Forms.Label lblgnltoplam;
        private System.Windows.Forms.TextBox txtGenelToplam;
        private System.Windows.Forms.DataGridView datamenu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Miktar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ürün_Adı;
        private System.Windows.Forms.DataGridViewTextBoxColumn BirimFiyat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Toplam;
        private System.Windows.Forms.Label lblTedarik;
        private System.Windows.Forms.Label lblÜrün;
        private System.Windows.Forms.Label lblSatıs;
        private System.Windows.Forms.Label lblMüsteri;
        private System.Windows.Forms.Label lblPersonel;
        private System.Windows.Forms.Label lblUrun;
        private System.Windows.Forms.DataGridView datagrdurun;
        private System.Windows.Forms.Label lblpersoneladı;
        private System.Windows.Forms.Label lblyetki;
        private System.Windows.Forms.Label lblTl;
    }
}